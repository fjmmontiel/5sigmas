from __future__ import annotations
import argparse, hashlib, json, math, os, subprocess, sys, time
from pathlib import Path
from typing import Iterable
import cairo
HERE = Path(__file__).resolve().parent
STORY = json.loads((HERE / 'story.json').read_text())
BG = '#FBFAF7'
INK = '#28241F'
ACCENT = '#67522E'
TINT = '#F3EEDF'
SERIES_BLUE = '#67522E'
SUCCESS = '#237345'
SUCCESS_WASH = '#E3F0E6'
MUTED = '#726B62'
RULE = '#DDD7CC'
RED = '#9A3E33'
ROSE = '#F4E5DD'
GOLD = '#8B5B1E'
SAND = '#F3EBDD'
WHITE = '#FFFFFF'
SERIF = 'Noto Serif Display'
SANS = 'Cabin'
TEXT_LAYOUT_CACHE = {}

def rgb(h):
    return tuple((int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)))

def clamp(x):
    return max(0.0, min(1.0, float(x)))

def ease(x):
    x = clamp(x)
    return x * x * (3 - 2 * x)

def blend(a, b, p):
    return tuple((x + (y - x) * p for x, y in zip(rgb(a), rgb(b))))

def L(lang, es, en):
    return es if lang == 'es' else en

class Draw:

    def __init__(self, ctx, w, h, lang='es', portrait=False):
        self.c = ctx
        self.w = w
        self.h = h
        self.lang = lang
        self.v = portrait
        self.bounds = []
        self.failures = []

    def color(self, col, alpha=1):
        r, g, b = rgb(col) if isinstance(col, str) else col
        self.c.set_source_rgba(r, g, b, clamp(alpha))

    def rect(self, x, y, w, h, fill=None, stroke=None, lw=2, alpha=1, r=0):
        c = self.c
        c.new_path()
        if r:
            r = min(r, w / 2, h / 2)
            c.arc(x + w - r, y + r, r, -math.pi / 2, 0)
            c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
            c.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
            c.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
            c.close_path()
        else:
            c.rectangle(x, y, w, h)
        if fill:
            self.color(fill, alpha)
            c.fill_preserve()
        if stroke:
            self.color(stroke, alpha)
            c.set_line_width(lw)
            c.stroke()
        else:
            c.new_path()

    def line(self, x1, y1, x2, y2, col=RULE, lw=2, alpha=1, dash=None):
        c = self.c
        c.new_path()
        c.move_to(x1, y1)
        c.line_to(x2, y2)
        self.color(col, alpha)
        c.set_line_width(lw)
        c.set_dash(dash or [])
        c.stroke()
        c.set_dash([])

    def circle(self, x, y, r, fill=None, stroke=None, lw=2, alpha=1):
        c = self.c
        c.new_path()
        c.arc(x, y, r, 0, math.tau)
        if fill:
            self.color(fill, alpha)
            c.fill_preserve()
        if stroke:
            self.color(stroke, alpha)
            c.set_line_width(lw)
            c.stroke()
        else:
            c.new_path()

    def font(self, size, bold=False, serif=False, text=''):
        family = SERIF if serif else ('DejaVu Sans' if any(ch in str(text) for ch in '≠−→←≤≥↔×÷∑√λμση₀₁₂₃₄₅₆₇₈₉̂θΣπ≈¹⁰²³∈∉∪∩∅∞∂∇') else SANS)
        self.c.select_font_face(family, cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL)
        self.c.set_font_size(size)

    def width(self, s, size, bold=False, serif=False):
        self.font(size, bold, serif, s)
        return self.c.text_extents(s).x_advance

    def lines(self, s, maxw, size, bold=False, serif=False):
        key = (str(s), round(maxw, 4), round(size, 4), bold, serif, tuple(round(z, 5) for z in self.c.get_matrix()))
        if key in TEXT_LAYOUT_CACHE:
            return TEXT_LAYOUT_CACHE[key]
        out = []
        for para in str(s).split('\n'):
            words = para.split()
            line = ''
            for word in words:
                new = (line + ' ' + word).strip()
                if line and self.width(new, size, bold, serif) > maxw:
                    out.append(line)
                    line = word
                else:
                    line = new
            out.append(line)
        TEXT_LAYOUT_CACHE[key] = out
        return out

    def text(self, s, x, y, size=30, col=INK, width=None, align='left', bold=False, serif=False, alpha=1, leading=1.21, record=True):
        lines = self.lines(s, width, size, bold, serif) if width else str(s).split('\n')
        self.font(size, bold, serif)
        for i, line in enumerate(lines):
            self.font(size, bold, serif, line)
            ext = self.c.text_extents(line)
            xx = x - (ext.x_advance / 2 if align == 'center' else ext.x_advance if align == 'right' else 0)
            yy = y + i * size * leading
            self.color(col, alpha)
            self.c.move_to(xx, yy + size * 0.84)
            self.c.show_text(line)
            if record and alpha > 0.02:
                box = (xx + ext.x_bearing, yy + size * 0.84 + ext.y_bearing, ext.width, ext.height, str(line))
                self.bounds.append(box)
                if box[0] < -1 or box[1] < -1 or box[0] + box[2] > self.w + 1 or (box[1] + box[3] > self.h + 1):
                    self.failures.append(('canvas_text_overflow', box))
        return len(lines) * size * leading

    def arrow(self, points, p=1, col=ACCENT, lw=3, alpha=1, head=True):
        """Grow a path in causal order; arrowhead follows the advancing endpoint."""
        p = clamp(p)
        n = len(points)
        if n < 2 or p <= 0:
            return
        ds = [math.dist(a, b) for a, b in zip(points, points[1:])]
        target = sum(ds) * p
        traced = 0
        end = points[0]
        direction = 0
        for a, b, d in zip(points, points[1:], ds):
            q = min(1, max(0, (target - traced) / max(d, 1e-09)))
            if q <= 0:
                break
            end = (a[0] + (b[0] - a[0]) * q, a[1] + (b[1] - a[1]) * q)
            self.line(*a, *end, col, lw, alpha)
            direction = math.atan2(b[1] - a[1], b[0] - a[0])
            traced += d
            if q < 1:
                break
        if head:
            k = 12
            self.line(*end, end[0] - k * math.cos(direction - 0.5), end[1] - k * math.sin(direction - 0.5), col, lw, alpha)
            self.line(*end, end[0] - k * math.cos(direction + 0.5), end[1] - k * math.sin(direction + 0.5), col, lw, alpha)

    def tick(self, x, y, size=16, col=SUCCESS, alpha=1):
        self.line(x - size * 0.6, y, x - size * 0.1, y + size * 0.45, col, 3, alpha)
        self.line(x - size * 0.1, y + size * 0.45, x + size * 0.75, y - size * 0.65, col, 3, alpha)

    def cross(self, x, y, size=13, col=RED, alpha=1):
        self.line(x - size, y - size, x + size, y + size, col, 3, alpha)
        self.line(x - size, y + size, x + size, y - size, col, 3, alpha)

class Graph:
    """A panel in native orientation. Labels stay native-sized; topology changes for portrait."""

    def __init__(self, d, x, y, w, h, p):
        self.d = d
        self.c = d.c
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.scale = w / 1000
        self.v = d.v
        self.lang = d.lang
        self.p = p
        self.H = h / self.scale
        self.base = len(d.bounds)

    def X(self, x):
        return self.x + x * self.scale

    def Y(self, y):
        return self.y + y * self.scale

    def rect(self, x, y, w, h, **kw):
        if 'lw' in kw:
            kw['lw'] *= self.scale
        if 'r' in kw:
            kw['r'] *= self.scale
        self.d.rect(self.X(x), self.Y(y), w * self.scale, h * self.scale, **kw)

    def line(self, x1, y1, x2, y2, **kw):
        if 'lw' in kw:
            kw['lw'] *= self.scale
        self.d.line(self.X(x1), self.Y(y1), self.X(x2), self.Y(y2), **kw)

    def circle(self, x, y, r, **kw):
        self.d.circle(self.X(x), self.Y(y), r * self.scale, **kw)

    def text(self, s, x, y, size=None, **kw):
        if size is None:
            size = 34 if self.v else 30
        if 'width' in kw:
            kw['width'] *= self.scale
        return self.d.text(s, self.X(x), self.Y(y), size * self.scale, **kw) / self.scale

    def label(self, es, en, x, y, **kw):
        return self.text(L(self.lang, es, en), x, y, **kw)

    def arrow(self, points, p=1, **kw):
        self.d.arrow([(self.X(x), self.Y(y)) for x, y in points], p, **kw)

    def tick(self, x, y, **kw):
        self.d.tick(self.X(x), self.Y(y), size=15 * self.scale, **kw)

    def cross(self, x, y, **kw):
        self.d.cross(self.X(x), self.Y(y), size=13 * self.scale, **kw)

    def box(self, x, y, w, h, es, en='', state='normal', alpha=1, size=None):
        color = {'normal': INK, 'active': ACCENT, 'pass': SUCCESS, 'unknown': GOLD, 'fail': RED, 'muted': MUTED}[state]
        fill = {'normal': WHITE, 'active': TINT, 'pass': SUCCESS_WASH, 'unknown': SAND, 'fail': ROSE, 'muted': BG}[state]
        self.rect(x, y, w, h, fill=fill, stroke=color if state != 'normal' else RULE, lw=2, alpha=alpha, r=3)
        s = L(self.lang, es, en or es)
        size = size or (34 if self.v else 30)
        lines = self.d.lines(s, (w - 26) * self.scale, size * self.scale, True)
        hh = len(lines) * size * 1.14
        if alpha > 0.02 and hh > h - 10:
            self.d.failures.append(('box_label_overflow', s, hh, h))
        self.text(s, x + w / 2, y + (h - hh) / 2, size=size, width=w - 26, align='center', bold=True, col=color, alpha=alpha, leading=1.14)

    def heading(self, es, en):
        self.label(es.upper(), en.upper(), 0, -2, size=22 if not self.v else 27, col=MUTED)

    def badge(self, es, en, y, state='active', alpha=1):
        self.box(60, y, 880, 80, es, en, state, alpha, size=33 if self.v else 30)

    def document(self, x, y, w=175, h=200, label='', state='normal', alpha=1):
        self.rect(x, y, w, h, fill=TINT if state == 'active' else WHITE, stroke=ACCENT if state == 'active' else RULE, alpha=alpha, lw=2)
        for i, q in enumerate([0.65, 0.83, 0.74, 0.53]):
            yy = y + 25 + i * 22
            if yy < y + h - 70:
                self.line(x + 18, yy, x + 18 + (w - 36) * q, yy, col=ACCENT if state == 'active' else RULE, lw=3, alpha=alpha)
        if label:
            self.text(label, x + w / 2, y + h - 50, size=28, align='center', col=ACCENT if state == 'active' else INK, alpha=alpha, bold=True)

    def caption(self, es, en, alpha=1):
        self.label(es, en, 500, self.H - 36, size=24 if self.v else 21, col=MUTED, align='center', width=980, alpha=alpha)

    def finish(self):
        for bx, by, bw, bh, s in self.d.bounds[self.base:]:
            if bx < self.x - 3 or bx + bw > self.x + self.w + 3 or by < self.y - 10 or (by + bh > self.y + self.h + 5):
                self.d.failures.append(('diagram_text_overflow', s, (bx, by, bw, bh), (self.x, self.y, self.w, self.h)))

def path_point(points, p):
    """Position on a polyline by traveled distance; deterministic, no loops."""
    p = clamp(p)
    ds = [math.dist(a, b) for a, b in zip(points, points[1:])]
    left = sum(ds) * p
    for a, b, d in zip(points, points[1:], ds):
        if left <= d:
            return (a[0] + (b[0] - a[0]) * left / max(d, 1e-09), a[1] + (b[1] - a[1]) * left / max(d, 1e-09))
        left -= d
    return points[-1]

def chapter_duration(ch):
    return sum((s['duration'] for s in ch['scenes']))

def locate(ch, t):
    acc = 0
    for i, s in enumerate(ch['scenes']):
        if t < acc + s['duration'] or i == len(ch['scenes']) - 1:
            return (i, s, t - acc)
        acc += s['duration']
    raise AssertionError

def render_frame(ch, lang, orientation, t, scale=1.0, audit=False):
    W, H = (1920, 1080) if orientation == 'h' else (1080, 1920)
    surface = cairo.ImageSurface(cairo.FORMAT_RGB24, round(W * scale), round(H * scale))
    ctx = cairo.Context(surface)
    ctx.scale(scale, scale)
    d = Draw(ctx, W, H, lang, orientation == 'v')
    d.color(BG)
    ctx.paint()
    v = d.v
    i, s, local = locate(ch, t)
    duration = chapter_duration(ch)
    margin = 66 if v else 70
    d.text('5sigmas', margin, 37 if not v else 47, 30 if not v else 36, bold=True)
    series = STORY['title'][lang]
    d.text(series, 220 if not v else 250, 45 if not v else 58, 17 if not v else 21, col=MUTED)
    d.text(f"{i + 1:02} / {len(ch['scenes']):02}", W - margin, 46 if not v else 59, 17 if not v else 21, col=MUTED, align='right')
    d.line(margin, 89 if not v else 111, W - margin, 89 if not v else 111, col=RULE, lw=1.5)
    if v:
        tx, ty, tw = (margin, 153, W - 2 * margin)
        title_size = 100
        body_size = 48
        body_leading = 1.2
        graph_x = margin
        graph_y = 995
        graph_w = W - 2 * margin
        graph_h = 730
    else:
        reverse = i in (2, 4)
        tx = 1095 if reverse else margin
        ty = 142
        tw = 755
        title_size = 77
        body_size = 40
        body_leading = 1.24
        graph_x = margin if reverse else 930
        graph_y = 237
        graph_w = 920
        graph_h = 714
    title_lines = d.lines(s['title'][lang], tw, title_size, True, True)
    while len(title_lines) > 3 and title_size > 66:
        title_size -= 2
        title_lines = d.lines(s['title'][lang], tw, title_size, True, True)
    title_h = len(title_lines) * title_size * 1.05
    for j, line in enumerate(title_lines):
        d.text(line, tx, ty + j * title_size * 1.05, title_size, col=ACCENT if j == len(title_lines) - 1 else INK, serif=True, bold=True, leading=1.05)
    body_y = ty + title_h + (36 if v else 34)
    active = max([-1] + [k for k, x in enumerate(s['cue_times']) if local >= x])
    y = body_y
    for k, text in enumerate(s['cues'][lang]):
        ls = d.lines(text, tw - 25, body_size)
        hh = len(ls) * body_size * body_leading
        reveal = ease((local - s['cue_times'][k]) / 0.3)
        if reveal > 0:
            if k == active:
                d.rect(tx - 7, y - 5, tw + 7, hh + 9, fill=TINT, alpha=reveal)
                d.line(tx - 14, y - 5, tx - 14, y + hh + 4, col=ACCENT, lw=3, alpha=reveal)
            d.text(text, tx + 5, y, body_size, col=ACCENT if k == active else INK, width=tw - 25, leading=body_leading, alpha=reveal)
        y += hh + 27
    if y > (1070 if v else 944):
        d.failures.append(('body_overflow', i, lang, orientation, y))
    if v:
        graph_y = max(965, y + 26)
        graph_h = 1760 - graph_y
    speeds = s['motion_seconds']
    ps = [ease((local - x) / dt) for x, dt in zip(s['visual_times'], speeds)]
    g = Graph(d, graph_x, graph_y, graph_w, graph_h, ps)
    DIAGRAMS[s['id']](g)
    g.finish()
    foot_y = 1786 if v else 982
    d.line(margin, foot_y - 20, W - margin, foot_y - 20, col=RULE, lw=1.2)
    provenance = L(lang, f"CAPÍTULO {ch['chapter']:02} · " + ch['title']['es'], f"CHAPTER {ch['chapter']:02} · " + ch['title']['en'])
    d.text(provenance, margin, foot_y, 20 if v else 17, col=MUTED, width=W - 2 * margin)
    note = L(lang, 'Ejemplo ilustrativo · no es un resultado de benchmark', 'Illustrative example · not a benchmark result') if s['illustrative'] else L(lang, 'Basado en el artículo de 5sigmas · fuentes y alcance en la serie', 'Based on the 5sigmas article · sources and scope in the series')
    d.text(note, margin, foot_y + (41 if v else 28), 20 if v else 16, col=MUTED, width=W - 2 * margin)
    ybar = 1873 if v else 1052
    for q, ss in enumerate(ch['scenes']):
        segment = (W - 2 * margin - 5 * (len(ch['scenes']) - 1)) / len(ch['scenes'])
        xx = margin + q * (segment + 5)
        d.line(xx, ybar, xx + segment, ybar, col=RULE, lw=2)
        proportion = 1 if q < i else clamp(local / ss['duration']) if q == i else 0
        if proportion:
            d.line(xx, ybar, xx + segment * proportion, ybar, col=SERIES_BLUE, lw=2)
    if audit:
        return (surface, d.failures, d.bounds)
    return surface

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for buf in iter(lambda: f.read(1024 * 1024), b''):
            h.update(buf)
    return h.hexdigest()

def render_video(ch, lang, orientation, out, fps=60, limit=None):
    w, h = (1920, 1080) if orientation == 'h' else (1080, 1920)
    duration = chapter_duration(ch) if limit is None else min(limit, chapter_duration(ch))
    n = round(duration * fps)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.stem + '.partial.mp4')
    cmd = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-filter_threads', '1', '-f', 'rawvideo', '-pix_fmt', 'bgr0', '-s', f'{w}x{h}', '-r', str(fps), '-i', '-', '-an', '-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p', '-c:v', 'libx264', '-preset', os.environ.get('ENCODE_PRESET', 'veryfast'), '-crf', '18', '-pix_fmt', 'yuv420p', '-r', str(fps), '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', '-color_range', 'tv', '-movflags', '+faststart', '-threads', os.environ.get('ENCODE_THREADS', '2'), str(tmp)]
    log = out.with_suffix('.encode.log')
    start = time.monotonic()
    with open(log, 'wb') as err:
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=err)
        try:
            for frame in range(n):
                surface = render_frame(ch, lang, orientation, frame / fps)
                surface.flush()
                p.stdin.write(surface.get_data())
                if frame % 600 == 0:
                    print(f'{out.stem} {frame}/{n}', flush=True)
            p.stdin.close()
            code = p.wait()
            if code:
                raise RuntimeError(f'ffmpeg exit {code}: {log.read_text()}')
        except BaseException:
            p.kill()
            p.wait()
            raise
    tmp.replace(out)
    receipt = {'file': out.name, 'chapter': ch['chapter'], 'language': lang, 'orientation': orientation, 'sha256': sha256(out), 'size': out.stat().st_size, 'duration': duration, 'fps': fps, 'width': w, 'height': h, 'elapsed_seconds': round(time.monotonic() - start, 2), 'state': 'CANDIDATE_UNREVIEWED', 'renderer_sha256': sha256(Path(__file__)), 'story_sha256': sha256(HERE / 'story.json')}
    out.with_suffix('.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    return receipt



from mechanisms import DIAGRAMS
