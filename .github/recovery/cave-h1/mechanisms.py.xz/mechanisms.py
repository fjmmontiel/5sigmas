"""Thirty-six causal mechanisms for the history of representation and computation."""
import math
from render import ACCENT,TINT,INK,BG,WHITE,MUTED,RULE,RED,ROSE,GOLD,SAND,SUCCESS,SUCCESS_WASH,L,clamp,ease,path_point
DIAGRAMS={}
def scene(f):DIAGRAMS[f.__name__]=f;return f
def txt(g,es,en,x,y,**k):return g.label(es,en,x,y,**k)
def title(g,es,en):g.heading(es,en)
def num(g,s,x,y,a=1,col=ACCENT,size=60):g.text(str(s),x,y,size=size,col=col,alpha=a,align='center',bold=True)
def card(g,x,y,w,es,en=None,a=1,state='normal',h=76):g.box(x,y,w,h,es,en or es,state,alpha=a,size=35 if g.v else 32)
def result(g,es,en,a=1):txt(g,es,en,500,g.H-112,size=33 if g.v else 30,col=ACCENT,bold=True,align='center',width=955,alpha=a)
def cap(g,es,en):g.caption(es,en)
def trace(g,pts,p,col=ACCENT):g.arrow(pts,p,col=col,lw=3)
def axis(g,x0=100,y0=490,x1=940,y1=105):
 g.line(x0,y0,x1,y0,col=INK,lw=2);g.line(x0,y0,x0,y1,col=INK,lw=2)
def poly(g,pts,p=1,col=ACCENT):
 if p<=0:return
 n=max(1,math.floor((len(pts)-1)*p));fract=(len(pts)-1)*p-n
 for a,b in zip(pts[:n+1],pts[1:n+1]):g.line(*a,*b,col=col,lw=4)
 if 0<=fract<1 and n<len(pts)-1:
  a,b=pts[n:n+2];g.line(*a,a[0]+(b[0]-a[0])*fract,a[1]+(b[1]-a[1])*fract,col=col,lw=4)
def tile(g,x,y,text,a=1,col=ACCENT,fill=TINT,w=82):
 g.rect(x,y,w,76,fill=fill,stroke=col,lw=2,alpha=a);g.text(text,x+w/2,y+20,size=33,align='center',bold=True,col=col,alpha=a)

@scene
def external_memory(g):
 a,b,c=g.p;title(g,'Siete objetos, siete marcas','Seven objects, seven marks')
 for k in range(7):
  x=107+k*128;g.circle(x,180,31,fill=TINT,stroke=ACCENT,lw=2,alpha=a*(1-c))
  g.line(x-12,326,x+12,404,col=ACCENT,lw=5,alpha=clamp(b*7-k))
  if b<1:g.line(x,235,x,302,col=RULE,lw=2,alpha=b*(1-c))
 g.line(58,443,931,443,col=INK,lw=2,alpha=b)
 num(g,'7',500,492,a=c,size=73)
 result(g,'El registro persiste cuando el objeto desaparece','The record persists when the object disappears',c);cap(g,'Reconstrucción conceptual, no datación de un objeto arqueológico.','Conceptual reconstruction, not an archaeological dating claim.')

@scene
def symbol_cost(g):
 a,b,c=g.p;title(g,'La misma cantidad, distinta representación','Same quantity, different representation')
 for k in range(24):
  x0=71+k%8*115;y0=114+k//8*94
  group=0 if k<10 else (1 if k<20 else 2);j=k%10 if k<20 else k-20
  x1=60+group*320+j%5*51;y1=143+j//5*117
  x=x0+(x1-x0)*b;y=y0+(y1-y0)*b;g.line(x,y,x+18,y+64,col=ACCENT,lw=4,alpha=a)
 for x,label in [(171,'10'),(491,'10'),(811,'4')]:g.text(label,x,398,size=46,bold=True,align='center',alpha=b)
 num(g,'2 × 10 + 4 = 24',500,499,a=c,size=61)
 result(g,'Los símbolos requieren una convención compartida','Symbols require a shared convention',c);cap(g,'Se conservan24 marcas y sus identidades durante el reagrupamiento.','All 24 marks retain their identities during regrouping.')

@scene
def program_separation(g):
 a,b,c=g.p;title(g,'Una máquina, dos procedimientos','One machine, two procedures')
 for x,s in [(44,'3'),(171,'4')]:tile(g,x,261,s,a,w=102)
 trace(g,[(286,299),(371,299)],a)
 g.rect(383,204,274,191,fill=WHITE,stroke=INK,lw=3,alpha=a);txt(g,'Máquina','Machine',520,221,align='center',size=37,bold=True,alpha=a)
 g.text('×' if b>.6 else '+',520,277,size=82,align='center',col=ACCENT,alpha=a)
 card(g,326,57,389,'Multiplicar','Multiply',a=b,h=90);trace(g,[(520,157),(520,196)],b)
 trace(g,[(671,299),(761,299)],a);num(g,'12' if b>.6 else '7',856,260,a=a,size=89)
 result(g,'3 + 4 = 7; 3 × 4 = 12','3 + 4 = 7; 3 × 4 = 12',c);cap(g,'Esquema funcional, no reconstrucción de una calculadora histórica.','Functional schematic, not a historical calculator reconstruction.')

@scene
def learned_mapping(g):
 a,b,c=g.p;title(g,'Puntos fijos; parámetros que cambian','Fixed data points; changing parameters')
 axis(g,x0=93,y0=487,x1=924,y1=106)
 slope=1+c
 for k in [1,2,3,4]:
  x=120+k*151;yt=487-79*k;yp=487-39.5*k*slope
  g.circle(x,yt,14,fill=ACCENT,alpha=a);g.line(x,yt,x,yp,col=GOLD,lw=3,alpha=b*(1-c))
 poly(g,[(120,487),(120+151*4,487-39.5*4*slope)],a,col=INK)
 num(g,f'w = {slope:.1f}',771,105,a=c,size=51)
 result(g,'El error guía el ajuste de una transformación','Error guides the update of a transformation',c);cap(g,'Relación lineal inventada para aislar el mecanismo de aprendizaje.','Invented linear relation isolates the learning mechanism.')

@scene
def parallel_work(g):
 a,b,c=g.p;title(g,'Cuatro operaciones independientes','Four independent operations')
 for k in range(4):
  x=45+k*218;g.rect(x,121,206,83,fill=TINT,stroke=ACCENT,lw=2,alpha=a);g.text(str(k+1),x+103,144,size=39,align='center',alpha=a)
 txt(g,'1 unidad: 20 pasos','1 unit: 20 steps',486,221,align='center',size=35,alpha=a)
 for k in range(4):
  x=45+k%2*218;y=326+k//2*118;g.rect(x,y,206,83,fill=TINT,stroke=ACCENT,lw=2,alpha=b);g.text(str(k+1),x+103,y+24,size=39,align='center',alpha=b)
 txt(g,'2 unidades','2 units',794,336,align='center',size=36,alpha=b);txt(g,'10 pasos ideales','10 ideal steps',794,410,align='center',size=36,alpha=b)
 result(g,'La comunicación y las dependencias limitan la ganancia','Communication and dependencies limit the gain',c);cap(g,'Cada operación cuesta5 pasos en este ejemplo sin sobrecoste.','Each operation takes 5 steps in this overhead-free example.')

@scene
def historical_map(g):
 a,b,c=g.p;title(g,'Capas que permanecen en el sistema','Layers that remain in the system')
 rows=[(96,'Parámetros aprendidos','Learned parameters',c),(210,'Programas','Programs',b),(324,'Símbolos y memoria','Symbols and memory',a),(438,'Soporte físico','Physical substrate',a)]
 for y,es,en,p in rows:
  g.rect(105,y,791,88,fill=TINT if y==96 else WHITE,stroke=ACCENT if y==96 else RULE,lw=2,alpha=p);txt(g,es,en,500,y+26,align='center',size=41,bold=True,alpha=p)
 for y,p in [(434,a),(320,b),(206,c)]:g.arrow([(68,y),(68,y-92)],p,lw=3,col=ACCENT)
 result(g,'Una nueva capacidad conserva dependencias anteriores','A new capability retains earlier dependencies',c);cap(g,'Ejemplo de capas, no una ley histórica ni una fecha para AGI.','Example layers, not a historical law or an AGI timeline.')

@scene
def tally_groups(g):
 a,b,c=g.p;title(g,'7 + 3, con conservación de unidades','7 + 3, preserving individual units')
 for k in range(10):
  p=a if k<7 else b;x0=60+k*92;y0=154;x1=104+k%5*171;y1=149+k//5*198
  x=x0+(x1-x0)*c;y=y0+(y1-y0)*c;g.line(x,y,x+21,y+83,col=ACCENT if k<7 else GOLD,lw=5,alpha=p)
 num(g,'7 + 3 = 10',500,498,a=b,size=68)
 result(g,'Dos grupos de cinco; diez unidades en total','Two groups of five; ten units in total',c);cap(g,'Las tres marcas nuevas son doradas para conservar su identidad.','The three added marks are gold to preserve their identity.')

@scene
def place_zero(g):
 a,b,c=g.p;title(g,'Centenas, decenas y unidades','Hundreds, tens and units')
 for k,lab in enumerate(['100','10','1']):
  x=130+k*309;g.text(lab,x+99,73,size=39,align='center',col=MUTED,alpha=a)
  g.rect(x,130,198,144,fill=TINT if k==1 and b>0 else WHITE,stroke=ACCENT if k==1 else RULE,lw=2,alpha=a);num(g,['1','0','5'][k],x+99,172,a=a,size=72)
 num(g,'105 = 100 + 0 + 5',500,327,a=b,size=58)
 for k,label in [(1,'1'),(2,'5')]:tile(g,179+k*309,454,label,c,w=105)
 result(g,'15 = 10 + 5, no 105','15 = 10 + 5, not 105',c);cap(g,'Eliminar un cero desplaza la cifra 1 a la columna de decenas.','Removing zero shifts digit 1 into the tens column.')

@scene
def balance_algebra(g):
 a,b,c=g.p;title(g,'Restar tres en ambos lados','Subtract three from both sides')
 num(g,'x + 3',241,108,a=a,size=69);num(g,'=',500,108,a=a,size=69);num(g,'8',747,108,a=a,size=69)
 for x in [240,747]:num(g,'−3',x,258,a=b,col=GOLD,size=64)
 g.line(94,354,908,354,col=INK,lw=3,alpha=b)
 num(g,'x',241,416,a=c,size=83);num(g,'=',500,416,a=c,size=69);num(g,'5',747,416,a=c,size=83)
 for x in [337,747]:g.line(x-60,181,x+60,94,col=GOLD,lw=3,alpha=b*(1-c))
 result(g,'La misma operación mantiene la igualdad','The same operation preserves equality',c);cap(g,'No restamos en un único lado de la ecuación.','We do not subtract on only one side of the equation.')

@scene
def sum_notation(g):
 a,b,c=g.p;title(g,'De una expansión a una expresión indexada','From expansion to an indexed expression')
 for k in range(6):
  x=41+k*157;num(g,str(k+1),x+52,113,a=a,size=62)
  if k<5:g.text('+',x+131,132,size=42,align='center',alpha=a)
 g.text('Σ',362,278,size=129,bold=True,align='center',col=ACCENT,alpha=b);g.text('6',362,235,size=33,align='center',alpha=b);g.text('i = 1',362,420,size=34,align='center',alpha=b)
 g.text('i',467,310,size=82,alpha=b);num(g,'= 21',671,319,a=c,size=71)
 result(g,'La convención compacta la descripción de la operación','The convention compresses the operation’s description',c);cap(g,'El índice recorre enteros de 1 a 6, incluidos ambos extremos.','The index runs from 1 through 6, including both endpoints.')

@scene
def deductive_sets(g):
 a,b,c=g.p;title(g,'A está contenido en B','A is contained in B')
 g.circle(500,312,227,fill=WHITE,stroke=ACCENT if c>0 else INK,lw=3+2*c,alpha=a)
 g.circle(442,344,115,fill=TINT,stroke=ACCENT,lw=3,alpha=a)
 g.text('B',676,189,size=62,bold=True,alpha=a);g.text('A',367,275,size=49,bold=True,alpha=a)
 g.circle(459,357,14,fill=GOLD,alpha=b);g.text('x',487,333,size=46,bold=True,col=GOLD,alpha=b)
 result(g,'x ∈ A y A dentro de B: x ∈ B','x ∈ A and A inside B: x ∈ B',c);cap(g,'La conclusión es condicional a las dos premisas.','The conclusion is conditional on both premises.')

@scene
def secant_limit(g):
 a,b,c=g.p;title(g,'y = x², alrededor de x = 1','y = x², near x = 1')
 axis(g,x0=90,y0=528,x1=934,y1=95)
 pts=[(110+350*x/50,528-100*(x/50)**2) for x in range(101)];poly(g,pts,a,col=MUTED)
 h=1-.75*b-.2*c;u=(460,428);v=(460+350*h,528-100*(1+h)**2)
 g.line(*u,*v,col=ACCENT,lw=4,alpha=a);g.circle(*u,11,fill=ACCENT,alpha=a);g.circle(*v,11,fill=GOLD,alpha=a)
 num(g,f'h = {h:.2f}',292,97,a=a,size=43);num(g,f'2 + h = {2+h:.2f}',703,97,a=b,size=45)
 result(g,'h → 0: pendiente → 2','h → 0: slope → 2',c);cap(g,'Los intervalos dibujados son finitos; el límite se declara aparte.','Drawn intervals are finite; the limit is stated separately.')
@scene
def mechanical_carry(g):
 a,b,c=g.p;title(g,'9 + 1: un paso y un acarreo','9 + 1: one step and one carry')
 carry=b>.999
 for x,es,en,digit in [(258,'Decenas','Tens','1' if carry else '0'),(751,'Unidades','Units','0' if carry else '9')]:
  g.circle(x,276,111,fill=WHITE,stroke=INK,lw=3,alpha=a)
  for k in range(10):
   q=2*math.pi*k/10+b*(2*math.pi/10 if x>500 else 0);g.line(x+93*math.cos(q),276+93*math.sin(q),x+107*math.cos(q),276+107*math.sin(q),col=RULE,lw=2,alpha=a)
  num(g,digit,x,225,a=a,size=97);txt(g,es,en,x,432,align='center',size=37,alpha=a)
 trace(g,[(747,151),(747,90),(261,90),(261,151)],b)
 txt(g,'Acarreo','Carry',500,36,size=36,align='center',alpha=b)
 result(g,'10 = 1 decena + 0 unidades','10 = 1 ten + 0 units',c);cap(g,'Estados decimales esquemáticos; no una máquina histórica exacta.','Schematic decimal states, not an exact historical machine.')

@scene
def punch_program(g):
 a,b,c=g.p;title(g,'El patrón vive fuera del mecanismo','The pattern lives outside the mechanism')
 pattern0=[1,0,1,0,0,1,0,1,1,0,1,0];pattern1=[1,1,0,0,1,1,0,0,1,1,0,0];pat=pattern1 if b>.5 else pattern0
 g.rect(38,99,305,379,fill=WHITE,stroke=INK,lw=3,alpha=a)
 for j,v in enumerate(pat):g.circle(87+j%4*68,181+j//4*113,18,fill=BG if v else MUTED,stroke=ACCENT if v else RULE,lw=2,alpha=a)
 card(g,401,202,194,'Selector','Selector',a=a,h=126);trace(g,[(350,265),(388,265)],a);trace(g,[(605,265),(651,265)],c)
 for j,v in enumerate(pat):g.rect(669+j%4*68,159+j//4*105,55,90,fill=TINT if v else WHITE,stroke=ACCENT if v else RULE,lw=2,alpha=c)
 result(g,'Nuevo patrón; mismo selector','New pattern; same selector',c);cap(g,'Esquema de selección por perforaciones, no un telar reconstruido.','Hole-based selection schematic, not a reconstructed loom.')

@scene
def boolean_circuit(g):
 a,b,c=g.p;title(g,'Dos interruptores en serie','Two switches in series')
 g.line(103,387,904,387,col=INK,lw=3,alpha=a);g.line(104,193,104,387,col=INK,lw=3,alpha=a);g.line(904,193,904,387,col=INK,lw=3,alpha=a)
 for u,v in [(104,252),(333,549),(631,839)]:g.line(u,193,v,193,col=INK,lw=3,alpha=a)
 for x,p,label in [(251,b,'A'),(550,c,'B')]:
  g.circle(x,193,7,fill=INK,alpha=a);g.circle(x+80,193,7,fill=INK,alpha=a);g.line(x,193,x+80,193-58*(1-p),col=ACCENT,lw=4,alpha=a);g.text(label,x+40,100,size=43,align='center',alpha=a)
 on=b>.999 and c>.999;g.circle(882,193,43,fill=TINT if on else WHITE,stroke=ACCENT if on else RULE,lw=3,alpha=a);num(g,'1' if on else '0',882,165,a=a,size=52)
 num(g,f'A={int(b>.999)} · B={int(c>.999)}',500,446,a=a,size=52)
 result(g,'Salida = A AND B','Output = A AND B',c);cap(g,'La salida cambia sólo al cerrarse por completo ambos interruptores.','The output changes only when both switches have fully closed.')

@scene
def tape_machine(g):
 a,b,c=g.p;title(g,'Incrementar una representación unaria','Incrementing a unary representation')
 for k in range(6):tile(g,52+k*153,160,'1' if k<3 or (k==3 and c>.5) else '_',a,w=123)
 x=113+3*153*b;g.line(x,265,x,324,col=ACCENT,lw=4,alpha=a);g.circle(x,359,30,fill=TINT,stroke=ACCENT,lw=3,alpha=a)
 txt(g,'Lee1 → mueve R','Read 1 → move R',214,438,align='center',size=34,alpha=b);txt(g,'Vacío → escribe 1 y STOP','Blank → write 1 and STOP',733,438,align='center',size=34,width=390,alpha=c)
 result(g,'111_ → 1111_','111_ → 1111_',c);cap(g,'Máquina de cinta mínima; no modela todas las máquinas de Turing.','Minimal tape machine; not a model of every Turing machine.')

@scene
def stored_instructions(g):
 a,b,c=g.p;title(g,'Memoria con código y datos','Memory containing code and data')
 rows=[('00','LOAD [03]'),('01','ADD [04]'),('02','STORE [05]'),('03','3'),('04','4'),('05','7' if c>.5 else '_')]
 active=2 if c>.01 else (1 if b>.65 else 0)
 for k,(addr,op) in enumerate(rows):
  y=81+k*79;g.rect(34,y,505,72,fill=TINT if k==active else WHITE,stroke=ACCENT if k==active else RULE,lw=2,alpha=a);g.text(addr,59,y+21,size=31,col=MUTED,alpha=a);g.text(op,165,y+17,size=36,bold=k==active,alpha=a)
 trace(g,[(550,116+active*79),(613,116+active*79),(613,242),(671,242)],b)
 g.rect(683,135,272,183,fill=WHITE,stroke=RULE,lw=2,alpha=a);txt(g,'Registro','Register',819,151,align='center',size=37,bold=True,alpha=a);num(g,'7' if b>.85 else ('3' if b>.4 else '0'),817,232,a=a,size=63)
 trace(g,[(818,327),(818,518),(551,518)],c)
 result(g,'Leer instrucción, operar, guardar','Fetch instruction, operate, store',c);cap(g,'Conjunto de instrucciones inventado para explicar la arquitectura.','Invented instruction set illustrating the architecture.')

@scene
def information_bits(g):
 a,b,c=g.p;title(g,'Una elección entre cuatro posibilidades','A choice among four possibilities')
 g.circle(500,111,34,fill=TINT,stroke=ACCENT,lw=3,alpha=a);num(g,'?',500,84,a=a,size=51)
 for x,bit in [(271,'0'),(730,'1')]:
  trace(g,[(500,151),(x,245)],b);g.circle(x,265,31,fill=WHITE,stroke=ACCENT,lw=2,alpha=b);g.text(bit,x,236,size=48,align='center',alpha=b)
 for j,label in enumerate(['A','B','C','D']):
  x=124+j*251;par=271 if j<2 else 730;trace(g,[(par,304),(x,403)],c);tile(g,x-49,411,label,c,w=98);g.text(f'{j:02b}',x,512,size=32,align='center',alpha=c)
 result(g,'log₂(4) = 2 bits','log₂(4) = 2 bits',c);cap(g,'Alternativas equiprobables; el significado no entra en este cálculo.','Equally likely alternatives; meaning is not part of this calculation.')

@scene
def rule_exceptions(g):
 a,b,c=g.p;title(g,'Caso: temperatura 80 y mantenimiento activo','Case: temperature 80 with maintenance active')
 card(g,51,121,373,'Si T > 70: alarma','If T > 70: alarm',a=a,h=112);card(g,51,323,373,'Si mantenimiento: silenciar','If maintenance: mute',a=b,h=112)
 trace(g,[(434,176),(584,176)],a);trace(g,[(434,379),(584,379)],b)
 card(g,598,121,349,'ALARMA','ALARM',a=a,h=112,state='active');card(g,598,323,349,'SILENCIO','MUTE',a=b,h=112)
 g.line(774,246,774,308,col=RED,lw=3,alpha=c);g.cross(774,277,col=RED,alpha=c)
 result(g,'Hace falta resolver prioridad o conflicto','Priority or conflict must be resolved',c);cap(g,'Reglas inventadas; no se ofrece control de un equipo real.','Invented rules, not instructions for operating real equipment.')

@scene
def heldout_curve(g):
 a,b,c=g.p;title(g,'Una función que interpola el entrenamiento','A function interpolating the training points')
 axis(g,x0=91,y0=493,x1=935,y1=111)
 f=lambda x:x+.75*math.sin(math.pi*x)
 pts=[(130+182*i/50,493-79*f(i/50)) for i in range(201)];poly(g,pts,a,col=ACCENT)
 for x in range(5):g.circle(130+182*x,493-79*x,13,fill=ACCENT,alpha=a)
 for x in [.5,1.5,2.5,3.5]:
  xx=130+182*x;yy=493-79*x;g.rect(xx-12,yy-12,24,24,fill=WHITE,stroke=GOLD,lw=3,alpha=b);g.line(xx,yy,xx,493-79*f(x),col=GOLD,lw=3,alpha=c)
 result(g,'Error cuadrático medio: entrenamiento 0 · reserva 0.5625','Mean squared error: training 0 · held-out 0.5625',c);cap(g,'Objetivo y=x; ajuste y=x+0.75sin(πx). Datos construidos.','Target y=x; fit y=x+0.75sin(πx). Constructed data.')

@scene
def gradient_step(g):
 a,b,c=g.p;title(g,'L(w) = (w − 3)²','L(w) = (w − 3)²')
 axis(g,x0=86,y0=509,x1=936,y1=103);pts=[(119+160*k/40,509-38*((k/40)-3)**2) for k in range(201)];poly(g,pts,a,col=MUTED)
 w=1.2*b;x=119+160*w;y=509-38*(w-3)**2;g.circle(x,y,16,fill=ACCENT,alpha=a)
 txt(g,'g(w0) = −6','g(w0) = −6',660,121,size=41,align='center',alpha=b);txt(g,'η = 0.2','η = 0.2',662,196,size=43,align='center',alpha=b)
 num(g,f'w = {w:.2f}',565,325,a=b,size=50)
 result(g,'w nuevo = 1.2 · pérdida = 3.24','New w = 1.2 · loss = 3.24',c);cap(g,'Un paso de gradiente; el punto objetivo está en w=3.','One gradient step; the target point is w=3.')

@scene
def xor_feature(g):
 a,b,c=g.p;title(g,'XOR: sólo una entrada activa','XOR: exactly one active input')
 for x,y,v in [(100,413,0),(100,150,1),(362,413,1),(362,150,0)]:
  g.circle(x,y,36,fill=TINT if v else WHITE,stroke=ACCENT if v else INK,lw=3,alpha=a);num(g,v,x,y-25,a=a,size=47)
 g.line(77,451,412,451,col=RULE,lw=2,alpha=a);g.line(63,117,63,452,col=RULE,lw=2,alpha=a)
 g.line(231,100,231,482,col=GOLD,lw=3,alpha=b);g.cross(231,91,col=GOLD,alpha=b)
 trace(g,[(424,290),(532,290)],c)
 g.line(585,292,939,292,col=INK,lw=3,alpha=c)
 for k in range(3):g.circle(603+k*150,292,25,fill=TINT if k==1 else WHITE,stroke=ACCENT if k==1 else RULE,lw=2,alpha=c);g.text(str(k),603+k*150,350,size=42,align='center',alpha=c)
 txt(g,'z=x1+x2','z=x1+x2',752,181,size=42,align='center',alpha=c)
 result(g,'Salida 1 cuando 0.5 < z < 1.5','Output 1 when 0.5 < z < 1.5',c);cap(g,'Dos umbrales no lineales distinguen el intervalo central.','Two nonlinear thresholds select the middle interval.')

@scene
def chain_rule(g):
 a,b,c=g.p;title(g,'Composición: x × w1 × w2','Composition: x × w1 × w2')
 vals=[('x','2'),('w1','3'),('h','6'),('w2','4'),('y','24')]
 for j,(name,val) in enumerate(vals):
  x=42+j*195;tile(g,x,160,val,a,w=131);g.text(name,x+66,91,size=41,align='center',alpha=a)
  if j<4:trace(g,[(x+141,198),(x+183,198)],a)
 for j,label in [(0,'×2'),(1,'×4'),(2,'8')]:
  x=250+j*252;g.text(label,x,369,size=57,bold=True,align='center',alpha=b)
  if j<2:trace(g,[(x+193,393),(x+75,393)],b)
 result(g,'∂L/∂w1 = 8 × 4 × 2 = 64','∂L/∂w1 = 8 × 4 × 2 = 64',c);cap(g,'L=(y−20)²; se muestran derivadas, no actualizaciones de pesos.','L=(y−20)²; derivatives are shown, not weight updates.')

@scene
def ngram_window(g):
 a,b,c=g.p;title(g,'El siguiente token ve sólo los dos anteriores','The next token sees only the previous two')
 rows=[(132,'Parque','River'),(343,'Préstamo','Loan')]
 for y,es,en in rows:
  card(g,25,y,270,es,en,a=a*(1-.65*b),h=96)
  for x,es2,en2 in [(367,'el','the'),(581,'banco','bank')]:card(g,x,y,180,es2,en2,a=a,h=96,state='active' if b>0 else 'normal')
  g.rect(345,y-18,439,133,stroke=ACCENT,lw=3,alpha=b);trace(g,[(793,y+48),(851,y+48)],c);g.text('?',912,y+11,size=78,bold=True,col=ACCENT,alpha=c)
 result(g,'Mismo sufijo de dos tokens: mismo contexto del trigrama','Same two-token suffix: same trigram context',c);cap(g,'Ejemplo de tokens-palabra; no es la tokenización de un LLM.','Word-token example, not an LLM tokenization.')

@scene
def convolution_filter(g):
 a,b,c=g.p;title(g,'Un filtro compartido, tres posiciones','One shared filter, three positions')
 col=0 if b<.5 else (1 if c<.5 else 3)
 for y in range(6):
  for x in range(6):
   g.rect(35+x*55,104+y*55,49,49,fill=TINT if x>=3 else WHITE,stroke=RULE,lw=1,alpha=a)
 g.rect(32+col*55,101+55,165,165,stroke=ACCENT,lw=4,alpha=a)
 for y in range(3):
  for x,val in enumerate([-1,0,1]):
   g.rect(466+x*92,165+y*83,88,79,fill=WHITE,stroke=RULE,lw=1,alpha=a);g.text(str(val),510+x*92,183+y*83,size=41,align='center',alpha=a)
 txt(g,'Filtro','Filter',604,95,size=37,align='center',alpha=a)
 trace(g,[(735,286),(816,286)],b)
 num(g,'3' if col==1 else '0',897,245,a=b,size=76)
 result(g,'Los pesos permanecen; cambia el parche de entrada','Weights stay fixed; the input patch changes',c);cap(g,'Píxeles 0/1; respuesta= suma de los productos del parche y filtro.','Pixels 0/1; response= sum of patch–filter products.')

@scene
def matrix_tiles(g):
 a,b,c=g.p;title(g,'Cuatro productos fila–columna independientes','Four independent row–column products')
 for ox,vals,name in [(70,[[1,2],[3,4]],'A'),(350,[[2,0],[1,2]],'B')]:
  g.text(name,ox+91,79,size=41,bold=True,align='center',alpha=a)
  for y in range(2):
   for x in range(2):tile(g,ox+x*98,146+y*88,str(vals[y][x]),a,w=83)
 g.text('×',305,208,size=49,align='center',alpha=a);trace(g,[(560,240),(656,240)],b)
 g.text('C',804,80,size=43,bold=True,align='center',alpha=b)
 for j,val in enumerate([4,4,10,8]):
  p=clamp(b*4-j);tile(g,712+j%2*104,146+j//2*88,str(val),p,w=92)
 txt(g,'C[1,1] = 1 × 2 + 2 × 1 = 4','C[1,1] = 1 × 2 + 2 × 1 = 4',500,443,size=40,align='center',alpha=c)
 result(g,'Calcular en paralelo no elimina mover datos','Parallel computation still requires moving data',c);cap(g,'Matriz 2×2 ilustrativa; no es una medición de rendimiento de GPU.','Illustrative 2×2 matrix, not a GPU performance measurement.')

@scene
def dense_attention(g):
 a,b,c=g.p;title(g,'Contar todos los pares de posiciones','Count every pair of positions')
 for y in range(4):
  for x in range(4):g.rect(58+x*49,159+y*49,44,44,fill=TINT,stroke=ACCENT,lw=1,alpha=a)
 num(g,'4² = 16',154,402,a=a,size=49)
 trace(g,[(296,270),(402,270)],b)
 for y in range(8):
  for x in range(8):
   old=x<4 and y<4;g.rect(454+x*49,81+y*49,44,44,fill=TINT if old else SAND,stroke=ACCENT if old else GOLD,lw=1,alpha=b if old else c)
 num(g,'8² = 64',655,498,a=c,size=49)
 result(g,'Duplicar N cuadruplica los pares de atención densa','Doubling N quadruples dense-attention pairs',c);cap(g,'Conteo sin máscara; no predice por sí solo memoria ni tiempo de kernel.','Unmasked pair count; it alone does not predict kernel memory or runtime.')

@scene
def compute_balance(g):
 a,b,c=g.p;title(g,'Presupuesto ilustrativo: N × D = 100','Illustrative budget: N × D = 100')
 axis(g,x0=86,y0=518,x1=932,y1=96)
 pts=[(107+30*n,518-20*(100/n)) for n in [5+i*.2 for i in range(101)]];poly(g,pts,a,col=MUTED)
 n=10+10*b;d=100/n;x=107+30*n;y=518-20*d;g.circle(x,y,15,fill=ACCENT,alpha=a)
 g.line(x,518,x,y,col=RULE,lw=2,alpha=a);g.line(86,y,x,y,col=RULE,lw=2,alpha=a)
 txt(g,'Tamaño N','Size N',924,545,size=31,align='right',alpha=a);txt(g,'Datos D','Data D',88,59,size=32,alpha=a)
 num(g,f'N = {n:.1f}',701,94,a=b,size=42);num(g,f'D = {d:.1f}',701,158,a=b,size=42)
 result(g,'El mejor reparto requiere medir la pérdida','The best allocation requires measuring loss',c);cap(g,'Unidades normalizadas; la curva es un supuesto de coste, no una ley de calidad.','Normalized units; the curve assumes cost, not model quality.')

@scene
def foundation_reuse(g):
 a,b,c=g.p;title(g,'Un conjunto de parámetros, varias tareas','One parameter set, several tasks')
 for j,(es,en) in enumerate([('Texto','Text'),('Código','Code'),('Documentos','Documents')]):card(g,28,115+j*118,237,es,en,a=a,h=85)
 g.rect(372,208,238,157,fill=TINT,stroke=ACCENT,lw=3,alpha=b);g.text('θ base',491,257,size=57,bold=True,align='center',col=ACCENT,alpha=b)
 for j in range(3):trace(g,[(276,157+j*118),(329,157+j*118),(329,286),(362,286)],b)
 for j,(es,en) in enumerate([('Resumir','Summarize'),('Traducir','Translate'),('Completar código','Complete code')]):
  y=100+j*153;trace(g,[(620,286),(675,286),(675,y+43),(708,y+43)],c);card(g,710,y-8,268,es,en,a=c,h=111)
 result(g,'Reutilización no significa calidad uniforme','Reuse does not imply uniform quality',c);cap(g,'Esquema de adaptación por instrucciones; un ajuste fino sí cambia parámetros.','Prompt adaptation schematic; fine-tuning does change parameters.')

@scene
def instruction_objective(g):
 a,b,c=g.p;title(g,'Aprender qué respuesta se prefiere','Learn which response is preferred')
 card(g,128,84,744,'Instrucción: suma 2 + 3','Instruction: add 2 + 3',a=a,h=84)
 for y,es,en in [(235,'A: continúa el enunciado…','A: continues the question…'),(388,'B: el resultado es 5','B: the result is 5')]:card(g,72,y,598,es,en,a=a,h=91)
 g.line(696,251,826,429,col=GOLD,lw=3,alpha=b);g.tick(850,431,alpha=b);txt(g,'Preferida','Preferred',848,498,size=33,align='center',alpha=b)
 result(g,'Se ajusta la conducta; no se garantiza toda respuesta','Behavior is adjusted; not every answer is guaranteed',c);cap(g,'Ejemplo de comparación de preferencias, no resultado de un proveedor.','Example preference comparison, not a provider result.')

@scene
def verified_search(g):
 a,b,c=g.p;title(g,'Objetivo 6: proponer no es verificar','Target 6: proposing is not verifying')
 candidates=[('1 + 5','6',True),('2 + 5','7',False),('3 + 3','6',True)]
 for j,(expr,answer,ok) in enumerate(candidates):
  y=108+j*144;card(g,57,y,300,expr,a=a,h=92);trace(g,[(366,y+46),(477,y+46)],b)
  num(g,answer,532,y+19,a=b,size=54);g.line(589,y+46,670,y+46,col=RULE,lw=2,alpha=b)
  if ok:g.tick(715,y+47,alpha=c);txt(g,'Conservar','Keep',779,y+26,size=35,alpha=c)
  else:g.cross(715,y+47,alpha=c);txt(g,'Rechazar','Reject',779,y+26,size=35,alpha=c)
 result(g,'El verificador puede descartar una rama concreta','The verifier can reject a specific branch',c);cap(g,'La suma exacta sirve de verificador en este ejemplo, no de garantía general.','Exact arithmetic is the verifier here, not a general guarantee.')

@scene
def selective_memory(g):
 a,b,c=g.p;title(g,'Guardar información no obliga a recuperarla toda','Stored information need not all be retrieved')
 for j,(es,en) in enumerate([('A · manual v1','A · manual v1'),('B · límite vigente: 5','B · current limit: 5'),('C · nota anterior','C · earlier note')]):
  y=103+j*151;card(g,30,y,516,es,en,a=a*(1-.55*b) if j!=1 else a,h=91,state='active' if j==1 and b>0 else 'normal')
 g.rect(610,128,334,332,fill=WHITE,stroke=ACCENT,lw=2,alpha=b);txt(g,'Contexto','Context',777,156,size=41,bold=True,align='center',alpha=b)
 trace(g,[(557,299),(646,299)],c);card(g,656,263,242,'B · límite 5','B · limit 5',a=c,h=93)
 result(g,'La procedencia y vigencia acompañan a lo recuperado','Provenance and validity accompany retrieved content',c);cap(g,'La memoria externa cambia la entrada; no actualiza los pesos del modelo.','External memory changes the input, not the model weights.')

@scene
def compact_state(g):
 a,b,c=g.p;title(g,'s nuevo = 0.5 × s anterior + x','New s = 0.5 × previous s + x')
 phase=0 if b<.5 else (1 if c<.5 else 2);vals=[1,.5,1.25]
 for j,x in enumerate([1,0,1]):
  tile(g,135+j*266,102,str(x),a,w=126);g.text(f'x{j+1}',198+j*266,55,size=33,align='center',alpha=a)
  if j==phase:g.rect(130+j*266,97,136,86,stroke=GOLD,lw=3,alpha=a)
 trace(g,[(198+phase*266,199),(198+phase*266,267),(500,267),(500,330)],a)
 g.rect(280,345,440,154,fill=TINT,stroke=ACCENT,lw=3,alpha=a);num(g,f's = {vals[phase]:g}',500,389,a=a,size=71)
 result(g,'Un estado de tamaño fijo resume la secuencia','A fixed-size state summarizes the sequence',c);cap(g,'s0=0. La compresión no preserva necesariamente toda información útil.','s0=0. Compression need not preserve every useful detail.')

@scene
def world_prediction(g):
 a,b,c=g.p;title(g,'Predicción y observación son objetos distintos','Prediction and observation are different objects')
 g.line(86,342,926,342,col=INK,lw=3,alpha=a)
 for k in range(5):
  x=90+k*198;g.line(x,332,x,352,col=INK,lw=2,alpha=a);g.text(f'{k*.5:g}',x,376,size=37,align='center',alpha=a)
 g.circle(90,342,20,fill=ACCENT,alpha=a*(1-b))
 predicted=90+792*b;g.circle(predicted,342,26,stroke=ACCENT,lw=4,alpha=b);txt(g,'Predicción 2','Prediction 2',836,162,align='center',size=37,alpha=b)
 actual=90+594;g.circle(actual,342,16,fill=GOLD,alpha=c);txt(g,'Observado 1.5','Observed 1.5',606,459,align='center',size=37,col=GOLD,alpha=c)
 g.line(actual,268,882,268,col=GOLD,lw=3,alpha=c);g.line(actual,253,actual,281,col=GOLD,lw=2,alpha=c);g.line(882,253,882,281,col=GOLD,lw=2,alpha=c)
 result(g,'Error de predicción: 2 − 1.5 = 0.5','Prediction error: 2 − 1.5 = 0.5',c);cap(g,'Transición escalar construida; no es una simulación física medida.','Constructed scalar transition, not a measured physical simulation.')

@scene
def feedback_control(g):
 a,b,c=g.p;title(g,'Objetivo 3; medir antes de actuar otra vez','Target 3; measure before acting again')
 card(g,25,165,247,'Control','Controller',a=a,h=100);card(g,377,165,247,'Acción 1','Action 1',a=b,h=100);card(g,729,165,247,'Sensor','Sensor',a=b,h=100)
 trace(g,[(282,215),(367,215)],b);trace(g,[(634,215),(719,215)],b)
 trace(g,[(852,281),(852,429),(148,429),(148,281)],c)
 txt(g,'Medida nueva: 0.8','New measurement: 0.8',500,467,size=41,align='center',alpha=c)
 num(g,'e = 2.2' if c>.5 else 'e = 3',147,92,a=a,size=42)
 result(g,'Error nuevo: 3 − 0.8 = 2.2','New error: 3 − 0.8 = 2.2',c);cap(g,'Entrada inicial 0; la acción manda 1, pero la respuesta medida es 0.8.','Initial reading 0; the command is 1, but the measured response is 0.8.')

@scene
def bounded_progress(g):
 a,b,c=g.p;title(g,'Un protocolo mide una capacidad concreta','A protocol measures a specific capability')
 for y,count,es,en,p in [(176,2,'Antes','Before',a),(337,7,'Después','After',b)]:
  txt(g,es,en,51,y-85,size=39,bold=True,alpha=p)
  for j in range(10):g.circle(70+j*95,y,27,fill=TINT if j<count else WHITE,stroke=ACCENT if j<count else RULE,lw=2,alpha=p)
  g.text(f'{count}/10',926,y+50,size=43,align='right',bold=True,col=ACCENT,alpha=p)
 result(g,'Mejorar aquí no establece generalidad universal','Improvement here does not establish universal generality',c);cap(g,'Resultados construidos; otras tareas y condiciones siguen sin medir.','Constructed results; other tasks and conditions remain unmeasured.')
